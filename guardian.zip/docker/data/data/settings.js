{
  "properties" : {
    "current.location" : ""
  },
  "import.local" : {
    "GuardianExample;;Text snippet 2023-08-29 11:53:29.414" : {
      "name" : "Text snippet 2023-08-29 11:53:29.414",
      "status" : "DONE",
      "message" : "Imported successfully in less than a second.",
      "context" : "",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/snippet/generated/d1c87ba4-1991-4e2d-8844-88f213be207b",
      "forceSerial" : false,
      "type" : "text",
      "format" : "text/turtle",
      "data" : "@prefix odrl: <http://www.w3.org/ns/odrl/2/> .\n@prefix prof: <http://www.w3.org/ns/dx/prof/> .\n@prefix dcat: <http://www.w3.org/ns/dcat#> .\n@prefix dct: <http://purl.org/dc/terms/> .\n@prefix spdx: <http://spdx.org/rdf/terms#> .\n@prefix : <http://example.contract.org#> .\n\n:QualityContract1 a :QualityContract ;\ndcat:identifier \"MyQualityContract\";\n    odrl:target [\n        a dcat:Dataset;\n        dcat:identifier \"LoadData\"\n    ] ;\n    prof:isProfileOf [\n        a :QualityConstraint;\n        dcat:identifier \"LoadedDataConstraint\";\n        :enforced true ;\n        prof:hasResource [\n            prof:hasArtifact <https://renedorsch.solidweb.org/validation_code/sensor_constraints.yml> ;\n            dct:conformsTo <https://specs.frictionlessdata.io/data-package/> ;\n            dct:format \"application/yaml\" ;\n            spdx:checksum [\n                spdx:algorithm <http://spdx.org/rdf/terms#checksumAlgorithm_sha256> ;\n                spdx:checksumValue \"54ed4c727f8ebaeab69ef8a6b57cb15a6d1fa26c20b0d80902f7357da4c797fd\"\n            ]\n        ]\n    ] .\n:QualityContract2 a :QualityContract ;\ndcat:identifier \"MyQualityContract\";\n    odrl:target [\n        a dcat:Dataset;\n        dcat:identifier \"ProcessData\"\n    ] ;\n    prof:isProfileOf [\n        a :QualityConstraint;\n        dcat:identifier \"ProcessedDataConstraint\";\n        :enforced true ;\n        prof:hasResource [\n            prof:hasArtifact <https://renedorsch.solidweb.org/validation_code/temperature_validation.py> ;\n            dct:conformsTo <http://python.org> ;\n            dct:format \"text/x-python\" ;\n            spdx:checksum [\n                spdx:algorithm <http://spdx.org/rdf/terms#checksumAlgorithm_md5> ;\n                spdx:checksumValue \"fda5c517ef55f972d553aca951caf506\"\n            ]\n        ]\n    ] .",
      "timestamp" : 1693302809725,
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true
      }
    }
  }
}