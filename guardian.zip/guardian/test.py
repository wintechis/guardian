import pyshacl
def validate_shacl(shacl_rules):
    def validate_shacl(data_graph):
        rules = shacl_rules
        return pyshacl.validate(data_graph=data_graph,
                                shacl_graph=rules)
    return validate_shacl



shapes_file = '''
@prefix dash: <http://datashapes.org/dash#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix schema: <http://schema.org/> .
@prefix sh: <http://www.w3.org/ns/shacl#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .

schema:PersonShape
    a sh:NodeShape ;
    sh:targetClass schema:Person ;
    sh:property [
        sh:path schema:givenName ;
        sh:datatype xsd:string ;
        sh:name "given name" ;
    ] ;
    sh:property [
        sh:path schema:gender ;
        sh:in ( "female" "male" ) ;
    ] ;
    sh:property [
        sh:path schema:address ;
        sh:node schema:AddressShape ;
    ] .

schema:AddressShape
    a sh:NodeShape ;
    sh:closed true ;
    sh:property [
        sh:path schema:streetAddress ;
        sh:datatype xsd:string ;
    ] ;
    sh:property [
        sh:path schema:postalCode ;
        sh:or ( [ sh:datatype xsd:string ] [ sh:datatype xsd:integer ] ) ;
        sh:minInclusive 10000 ;
        sh:maxInclusive 99999 ;
    ] .
'''
shapes_file_format = 'turtle'

data_file = '''
@prefix schema: <http://schema.org/> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .

<http://example.org/ns#Bob>
  a schema:Person ;
  schema:address <http://example.org/ns#BobsAddress> ;
  schema:birthDate "1971-07-07"^^xsd:string ;
  schema:deathDate "1968-09-10"^^xsd:string ;
  schema:familyName "Junior"^^xsd:string ;
  schema:givenName "Robert"^^xsd:string .

<http://example.org/ns#BobsAddress>
  schema:postalCode 9404 ;
  schema:streetAddress "1600 Amphitheatre Pkway"^^xsd:string .
'''
data_file_format = 'json-ld'

validate = validate_shacl(shapes_file)

conforms, _, error_message = validate(data_file)
print(conforms)
print(error_message)
