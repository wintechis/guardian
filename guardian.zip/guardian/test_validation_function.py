def validate(temperature):
    """ The sensor can only measure in a temperature range between -5 and 30 degree clesius """
    if temperature < -5 or temperature > 30 :
        return False
    return True