# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['guardian']

package_data = \
{'': ['*']}

install_requires = \
['SPARQLWrapper>=2.0.0,<3.0.0',
 'luigi>=3.3.0,<4.0.0',
 'pandera[io]>=0.16.1,<0.17.0',
 'pyshacl>=0.23.0,<0.24.0',
 'pytest>=7.4.0,<8.0.0',
 'rdflib<7.0.0']

setup_kwargs = {
    'name': 'guardian',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Rene Dorsch',
    'author_email': 'rene.dorsch@iis.fraunhofer.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
